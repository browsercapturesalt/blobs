const fs = require("fs");
const parse = require("parse-git-config");

const gitConfig = parse.sync();

const originUrl = gitConfig['remote "origin"'].url.replace(/\.git$/, "");

const targzurl = originUrl + "/blob/master/repo.tar.gz?raw=true";

const readmeTemplate = fs.readFileSync("ReadMe.template.md").toString();

const readme = readmeTemplate.replaceAll(
  "GITPOD_URL",
  "https://gitpod.io/#" + originUrl
);

fs.writeFileSync("ReadMe.md", readme);

const pkg = require("./package.json");

pkg.targzurl = targzurl;

fs.writeFileSync("package.json", JSON.stringify(pkg, null, 2));
