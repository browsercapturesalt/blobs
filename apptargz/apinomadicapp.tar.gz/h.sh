. env.sh

node heroku.js $*