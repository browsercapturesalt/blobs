node actualize.js

git add .
git commit -m "$*"
git push --set-upstream origin master