let VERBOSE = false;

function log(...args) {
  if (VERBOSE) console.log(...args);
}

const prompt = require("prompt-sync")();

const fetch = require("node-fetch");
const fs = require("fs");

const argv = require("minimist")(process.argv.slice(2));

//////////////////////////////////////////////////////////////////

const pkg = require("./package.json");

const heroku = pkg.heroku;
const command = argv._[0];
delete argv._;

const appName = argv.name || heroku.appname;
const targzurl =
  argv.url || process.env.HEROKUTARGZBUILD_TARGZURL || pkg.targzurl;

const API_BASE_URL = "https://api.heroku.com";

let defaultTokenName = "HEROKU_TOKEN";
let defaultToken = process.env[defaultTokenName];

var config = {};

pkg.heroku.configvars.forEach((cv) => (config[cv] = process.env[cv] || null));

//////////////////////////////////////////////////////////////////

function confirm(msg, defaultCancel) {
  const answer = prompt(
    "Are you sure you want to " +
      msg +
      " ? ( y = Yes, n = No, ENTER = " +
      (defaultCancel ? "No" : "Yes") +
      " ) "
  );

  if (!answer) {
    return !defaultCancel;
  }

  return defaultCancel ? answer.match(/^y/i) : !answer.match(/^n/i);
}

function fetchText(url) {
  //log("fetch text", url);
  return new Promise((resolve, reject) => {
    try {
      fetch(url)
        .then((response) => {
          //log("response", response);
          response
            .text()
            .then((text) => {
              //log("got text size", text.length);
              resolve(text);
            })
            .catch((err) => {
              const errMsg = `could not get response text ${err}`;
              log("error", errMsg);
              reject(errMsg);
            });
        })
        .catch((err) => {
          const errMsg = `could not get response ${err}`;
          log("error", errMsg);
          reject(errMsg);
        });
    } catch (err) {
      const errMsg = `fetch error ${err}`;
      log(errMsg);
      reject(errMsg);
    }
  });
}

function api(endpoint, method, payload, token, accept) {
  const url = `${API_BASE_URL}/${endpoint}`;
  const headers = {
    Authorization: `Bearer ${token || defaultToken}`,
    Accept: accept || "application/vnd.heroku+json; version=3",
    "Content-Type": "application/json",
  };
  const body = payload ? JSON.stringify(payload) : undefined;
  if (require.main === module) {
    log({ endpoint, method, url, headers, payload, token, body });
  }
  return new Promise((resolve, reject) => {
    fetch(url, {
      method,
      headers,
      body,
    }).then(
      (resp) =>
        resp.json().then(
          (json) => resolve(json),
          (err) => {
            console.error(err);
            reject(err);
          }
        ),
      (err) => {
        console.error(err);
        reject(err);
      }
    );
  });
}

function get(endpoint, payload, token, accept) {
  return api(endpoint, "GET", payload, token, accept);
}

function post(endpoint, payload, token, accept) {
  return api(endpoint, "POST", payload, token, accept);
}

function del(endpoint, payload, token, accept) {
  return api(endpoint, "DELETE", payload, token, accept);
}

function patch(endpoint, payload, token, accept) {
  return api(endpoint, "PATCH", payload, token, accept);
}

function getSchema() {
  get("schema").then((json) =>
    fs.writeFileSync("schema.json", JSON.stringify(json, null, 2))
  );
}

function createApp(name, token) {
  return new Promise((resolve) => {
    post("apps", { name }, token).then((json) => {
      if (require.main === module) {
        log(json);
      }

      resolve(json);
    });
  });
}

function delApp(name, token) {
  return new Promise((resolve) => {
    del(`apps/${name}`, undefined, token).then((json) => {
      if (require.main === module) {
        log(json);
      }

      resolve(json);
    });
  });
}

function getConfig(name, token) {
  return new Promise((resolve) => {
    get(`apps/${name}/config-vars`, undefined, token).then((json) => {
      if (require.main === module) {
        log(json);
      }

      resolve(json);
    });
  });
}

function getAccount(token) {
  return new Promise((resolve) => {
    get(`account`, undefined, token).then((json) => {
      if (require.main === module) {
        log(json);
      }

      resolve(json);
    });
  });
}

function getQuota(token) {
  return new Promise((resolve) => {
    getAccount(token).then((acc) => {
      get(
        `accounts/${acc.id}/actions/get-quota`,
        undefined,
        token,
        "application/vnd.heroku+json; version=3.account-quotas"
      ).then((json) => {
        json.acc = acc;

        if (require.main === module) {
          log(json);
        }

        resolve(json);
      });
    });
  });
}

function getRichQuota(tokenOpt) {
  const token = tokenOpt || defaultToken;

  return new Promise((resolve) => {
    Promise.all([getQuota(token), getApps(token)]).then((items) => {
      const [quota, apps] = items;

      const json = {
        quota,
        apps,
      };

      let allUsedQuota = 0;
      for (let qApp of quota.apps) {
        const appId = qApp.app_uuid;
        const app = apps.find((app) => app.id === appId);
        if (app) {
          app.usedQuota = qApp.quota_used;
          allUsedQuota += app.usedQuota;
          app.accountQuota = quota.account_quota;
        }
      }

      json.accountQuota = json.quota.account_quota;
      json.accountUsedQuota = allUsedQuota;
      json.accountRemainingQuota = json.accountQuota - json.accountUsedQuota;

      for (let app of apps) {
        app.remainingQuota = json.accountRemainingQuota;
        app.usedQuota = app.usedQuota || 0;
      }

      const alltokens = getAllTokens();
      json.accountHerokuToken = token;
      json.accountHerokuName = alltokens.herokuNameByToken[token];

      if (require.main === module) {
        log(JSON.stringify(json, null, 2));
      }

      resolve(json);
    });
  });
}

function setConfig(name, configVars, token) {
  return new Promise((resolve) => {
    patch(`apps/${name}/config-vars`, configVars || config, token).then(
      (json) => {
        if (require.main === module) {
          log(json);
        }

        resolve(json);
      }
    );
  });
}

function getLogs(name, token, lines, tail) {
  return new Promise((resolve) => {
    post(
      `apps/${name}/log-sessions`,
      { lines: lines || 100, tail: tail || false },
      token
    ).then((json) => {
      fetchText(json.logplex_url)
        .then((text) => {
          //log("fetched logs text size", text.length);
          json.logText = `${text}`;
          json.logLines = json.logText
            .replace(/\r/g, "")
            .split("\n")
            .filter((line) => line.length);
          json.logItems = json.logLines.map((line) => {
            const m = line.match(/([^ ]+) ([^ ]+): (.*)/);
            return { time: m[1], dyno: m[2], content: m[3] };
          });

          if (require.main === module) {
            log(json);
          }

          resolve(json);
        })
        .catch((err) => {
          log("error fetching log text", err);
          json.error = err;
          json.logText = err;
          json.logLines = [];
          json.logItems = [];

          if (require.main === module) {
            log(json);
          }

          resolve(json);
        });
    });
  });
}

function getBuilds(name, token) {
  return new Promise((resolve) => {
    get(`apps/${name}/builds`, undefined, token).then((json) => {
      if (require.main === module) {
        log(json);
      }

      resolve(json);
    });
  });
}

function getApps(tokenOpt) {
  const token = tokenOpt || defaultToken;
  return new Promise((resolve) => {
    get("apps", undefined, token).then((json) => {
      if (require.main === module) {
        log(json);
      }
      const alltokens = getAllTokens();
      try {
        json.forEach((app) => {
          app.herokuToken = token;
          app.herokuName = alltokens.tokensByToken[token].split("_")[2];
        });
      } catch (err) {
        log(err, token, alltokens);
      }
      resolve(json);
    });
  });
}

function getAllApps() {
  return new Promise((resolve) => {
    const alltokens = getAllTokens();

    Promise.all(
      Object.keys(alltokens.tokensByToken).map((token) => getApps(token))
    ).then((appss) => {
      const apps = appss
        .flat()
        .sort((a, b) => {
          if (a.herokuName != b.herokuName)
            return a.herokuName.localeCompare(b.herokuName);
          return a.name.localeCompare(b.name);
        })
        .map((app) => {
          app.herokuIndex = alltokens.herokuNames.findIndex(
            (name) => app.herokuName === name
          );
          return app;
        });

      if (require.main === module) {
        log(apps);
      }

      resolve(apps);
    });
  });
}

function buildApp(name, url, token) {
  return new Promise((resolve) => {
    post(
      `apps/${name}/builds`,
      {
        source_blob: {
          checksum: null,
          url,
          version: null,
        },
      },
      token
    ).then((json) => {
      if (require.main === module) {
        log(json);
      }

      resolve(json);
    });
  });
}

function restartAllDynos(name, token) {
  return new Promise((resolve) => {
    del(`apps/${name}/dynos`, undefined, token).then((json) => {
      if (require.main === module) {
        log(json);
      }

      resolve(json);
    });
  });
}

function getAllTokens() {
  const tokensByName = {};
  const tokensByToken = {};
  const namesByName = {};
  const herokuNameByToken = {};
  const herokuNames = [];
  Object.keys(process.env)
    .filter((key) => key.match(new RegExp("^HEROKU_TOKEN_")))
    .forEach((token) => {
      const envToken = process.env[token];
      const herokuName = token.split("_")[2];
      tokensByName[token] = envToken;
      tokensByToken[envToken] = token;
      namesByName[token] = herokuName;
      herokuNameByToken[envToken] = herokuName;
      herokuNames.push(herokuName);
    });
  return {
    tokensByName,
    tokensByToken,
    namesByName,
    herokuNameByToken,
    herokuNames: herokuNames.sort((a, b) => a.localeCompare(b)),
  };
}

async function createConfigAndBuildConfirmed() {
  if (
    confirm(
      `create <${appName}>, set default config, and build from <${targzurl}>`
    )
  ) {
    await createApp(appName);
    await setConfig(appName);
    await buildApp(appName, targzurl);
  }
}

async function interpreter() {
  console.log(command, argv, defaultTokenName);

  if (command === "create") {
    const result = await createApp(appName);
    if (result.message) {
      console.log("could not create", appName, result.message);
    } else {
      console.log("created", appName, "id", result.id);
    }
  } else if (command === "del") {
    const result = await delApp(appName);
    if (result.message) {
      console.log("could not delete", appName, result.message);
    } else {
      console.log("deleted", appName);
    }
  } else if (command === "build") {
    const result = await buildApp(appName, targzurl);
    console.log("build", appName, result.status);
  } else if (command === "csb") {
    createConfigAndBuildConfirmed();
  } else if (command === "schema") {
    getSchema();
  } else if (command === "getconfig") {
    getConfig(appName);
  } else if (command === "setconfig") {
    const result = await setConfig(appName);
    console.log("config set", appName, "keys", Object.keys(result).length);
  } else if (command === "getapps") {
    getApps();
  } else if (command === "getallapps") {
    getAllApps();
  } else if (command === "gettokens") {
    log(getAllTokens());
  } else if (command === "getlogs") {
    getLogs(appName);
  } else if (command === "getbuilds") {
    getBuilds(appName);
  } else if (command === "restartall") {
    restartAllDynos(appName);
  } else if (command === "acc") {
    getAccount();
  } else if (command === "quota") {
    getQuota();
  } else if (command === "richquota") {
    getRichQuota();
  } else {
    console.error("unknown command");
  }
}

if (require.main !== module) {
  module.exports = {
    getApps,
    getAllTokens,
    getAllApps,
    createApp,
    delApp,
    getLogs,
    getBuilds,
    buildApp,
    getConfig,
    setConfig,
    restartAllDynos,
    getAccount,
    getQuota,
    getRichQuota,
  };
} else {
  interpreter();
}
