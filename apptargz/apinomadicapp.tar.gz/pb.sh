. env.sh

. p.sh $*

. archive.sh

. h.sh create
. h.sh setconfig
. h.sh build
