. env.sh

. p.sh $*

. archive.sh

. h.sh deploy
