node actualize.js

yarn pretty

git add .
git commit -m "$*"
git push --set-upstream origin master
