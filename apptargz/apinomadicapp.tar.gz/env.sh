eval $(gp env -e)
eval $(node_modules/@browsercapturesalt/config/bin/env)