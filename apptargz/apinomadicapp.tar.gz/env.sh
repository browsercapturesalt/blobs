eval $(node_modules/@browsercapturesalt/config/bin/env)
eval $(gp env -e)