. s/env

node dist/index.js serve