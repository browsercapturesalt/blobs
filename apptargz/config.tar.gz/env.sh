eval $(bin/env)
eval $(gp env -e)