. env.sh

node server/server.js