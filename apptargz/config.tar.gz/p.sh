yarn pretty

git add -A
git commit -m "$*"
git push --set-upstream origin main
