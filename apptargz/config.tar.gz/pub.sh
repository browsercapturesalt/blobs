node bump.js

. p.sh "$*"

. auth.sh

npm publish --access=public